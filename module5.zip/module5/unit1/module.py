"""
A simple module.

This file shows how modules work

Author: Walker M. White (wmw2)
Date:   July 31, 2018
"""

x = 1+2
x = 3*x

# Add your edits here
